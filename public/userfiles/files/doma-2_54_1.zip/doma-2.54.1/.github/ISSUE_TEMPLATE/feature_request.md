---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: nakamura-to

---

**Description**
(Describe the feature here.)

**Implementation ideas**
(If you have any implementation ideas, they can go here)
