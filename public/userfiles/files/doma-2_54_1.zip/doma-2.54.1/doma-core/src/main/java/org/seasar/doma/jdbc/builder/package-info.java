/** Provides classes to build dynamic SQL statements. */
package org.seasar.doma.jdbc.builder;
