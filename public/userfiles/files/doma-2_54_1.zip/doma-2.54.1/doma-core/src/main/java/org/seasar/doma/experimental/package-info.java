/**
 * Provides experimental annotations.
 *
 * <p>All features provided by this package may change without further notice.
 */
package org.seasar.doma.experimental;
