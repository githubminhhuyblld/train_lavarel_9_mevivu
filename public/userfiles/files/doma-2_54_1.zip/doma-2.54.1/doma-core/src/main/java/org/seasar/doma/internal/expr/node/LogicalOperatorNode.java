package org.seasar.doma.internal.expr.node;

public interface LogicalOperatorNode extends OperatorNode {}
