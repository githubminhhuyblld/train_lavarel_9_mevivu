/** Provides classes and interfaces to execute SQL statements. */
package org.seasar.doma.jdbc.command;
