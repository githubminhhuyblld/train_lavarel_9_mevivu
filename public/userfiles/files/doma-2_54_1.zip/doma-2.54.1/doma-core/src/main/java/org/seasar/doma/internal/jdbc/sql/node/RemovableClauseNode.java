package org.seasar.doma.internal.jdbc.sql.node;

public interface RemovableClauseNode extends ClauseNode {}
