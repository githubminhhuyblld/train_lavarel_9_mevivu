package org.seasar.doma.internal;

public class WrapException extends Exception {

  private static final long serialVersionUID = 1L;

  public WrapException(Throwable cause) {
    super(cause);
  }
}
