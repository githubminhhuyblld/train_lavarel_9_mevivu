/** Provides class related to expressions. */
package org.seasar.doma.expr;
