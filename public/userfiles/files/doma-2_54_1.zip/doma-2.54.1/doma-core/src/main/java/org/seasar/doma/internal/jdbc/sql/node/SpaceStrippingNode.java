package org.seasar.doma.internal.jdbc.sql.node;

public interface SpaceStrippingNode extends AppendableSqlNode {

  void clearChildren();
}
