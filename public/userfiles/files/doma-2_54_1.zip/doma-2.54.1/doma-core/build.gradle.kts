description = "doma-core"

dependencies {
    testImplementation(project(":doma-mock"))
}
